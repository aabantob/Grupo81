<?php
header('Content-type:application/json;charset=UTF-8');
/*
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'L:\xampp\composer\vendor\autoload.php';
*/

require("PHPMailer/class.phpmailer.php");
require("PHPMailer/class.smtp.php");

date_default_timezone_set('America/Lima');


include_once('database.php');

if($_SERVER['REQUEST_METHOD'] === 'POST'){

  $nombres = htmlspecialchars(strip_tags(trim($_POST['txt_nombres'])));
  $apellidos = htmlspecialchars(strip_tags(trim($_POST['txt_apellidos'])));
  $telefono = htmlspecialchars(strip_tags(trim($_POST['txt_phone'])));
  $email = htmlspecialchars(strip_tags(trim($_POST['txt_email'])));
  $mensaje = htmlspecialchars(strip_tags(trim($_POST['txt_mensaje'])));


  $stmt = $con->prepare("INSERT INTO contacto (nombres,apellidos,telefono,email,mensaje) VALUES (:nombres,:apellidos,:telefono,:email,:mensaje)");
  $stmt->bindParam(":nombres", $nombres);
  $stmt->bindParam(":apellidos", $apellidos);
  $stmt->bindParam(":telefono", $telefono);
  $stmt->bindParam(":email", $email);
  $stmt->bindParam(":mensaje", $mensaje);


  if($stmt->execute()){

    $mail = new PHPMailer(true);

    try {
      
      $ServidorCorreo="otros"; //"otros" //"gmail"

      if($ServidorCorreo=="gmail"){
        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";		
        $mail->Port       = 465;  
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl"; 
        $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
        
        //Sustituye  ( CuentaDeEnvio )  por la cuenta desde la que deseas enviar por ejem. prueba@domitienda.com  
        $mail->From     = "entelcom.sys@gmail.com";
        $mail->FromName = "Entelcom Sys";
        $mail->Subject  = "Hola este es una prueba de mail";
        $mail->AltBody  = "Leer"; 

        $body = '<html lang="es">
        <head>
          <title></title>
          <style>*{padding:0;margin:0;}</style>
        </head>
        <body>hola</body></html>';

        $mail->MsgHTML($body);
      
        // Sustituye  (CuentaDestino )  por la cuenta a la que deseas enviar por ejem. usuario@destino.com  
        $mail->AddAddress($email,'');
        $mail->SMTPAuth = true;
      
        // Sustituye (CuentaDeEnvio )  por la misma cuenta que usaste en la parte superior en este caso  prueba@midominio.com  y sustituye (ContraseñaDeEnvio)  por la contraseña que tenga dicha cuenta 
        $mail->Username = "entelcom.sys@gmail.com";
        $mail->Password = "aabanto12345";
      }else{

        $mail->isSMTP();
        $mail->Host = "smtpout.secureserver.net";		
        $mail->Port       = 465;  
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "ssl"; 
        $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
        
        //Sustituye  ( CuentaDeEnvio )  por la cuenta desde la que deseas enviar por ejem. prueba@domitienda.com  
        $mail->From     = "techquerys@techwomancode.com";
        $mail->FromName = "TWC mail";
        $mail->Subject  = "Hola este es una prueba de mail";
        $mail->AltBody  = "Leer"; 

        $body = '<html lang="es">
        <head>
          <title></title>
          <style>*{padding:0;margin:0;}</style>
        </head>
        <body>
          <div>
            <div style="width:800px;max-width: 800px;margin: 0 auto;font-family: "OpenSans",sans-serif;">
              <div><img src="https://registrate.zestcapital.com.pe/img/banner-mail.png" alt="" style="width:100%"></div>
              <div style="padding: 35px 15px; color: #575757;background: #f1f1f1">
                <table style="width: 100%; text-align: center;">
                  <thead>
                    <tr>
                      <th><img src="https://registrate.zestcapital.com.pe/img/mail/calendario.svg" width="65px" alt=""></th>
                      <th><img src="https://registrate.zestcapital.com.pe/img/mail/hora.svg" width="65px" alt=""></th>
                      <th><img src="https://registrate.zestcapital.com.pe/img/mail/ubicacion.svg" width="65px" alt=""></th>
                    </tr>
                  </thead>
                  <tbody style="width: 100%; text-align: center;">
                    <tr>
                      <td style="padding: 10px 0; font-weight: bold; color: #D9BC03;">FECHA: </td>
                      <td style="padding: 10px 0; font-weight: bold; color: #D9BC03;">HORA: </td>
                      <td style="padding: 10px 0; font-weight: bold; color: #D9BC03;">LUGAR: </td>
                    </tr>
                    <tr>
                      <td style="padding: 10px 0; color: #575757;">5 de Setiembre, 2019</td>
                      <td style="padding: 10px 0; color: #575757;"> pruebaaaa </td>
                      <td style="padding: 10px 0; color: #575757;">Av. Javier Prado Este 6230<br> IBM Sala Cuzco</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div><img src="https://registrate.zestcapital.com.pe/img/footer-mail.png" alt="" style="width: 100%"></div>
            </div>
          </div>
        </body>
        </html>';

        $mail->MsgHTML($body);
      
        // Sustituye  (CuentaDestino )  por la cuenta a la que deseas enviar por ejem. usuario@destino.com  
        $mail->AddAddress($email,'');
        $mail->SMTPAuth = true;
      
        // Sustituye (CuentaDeEnvio )  por la misma cuenta que usaste en la parte superior en este caso  prueba@midominio.com  y sustituye (ContraseñaDeEnvio)  por la contraseña que tenga dicha cuenta 
        $mail->Username = "techquerys@techwomancode.com";
        $mail->Password = "Unicorn19*";
      }
      /*
      $mail->Host       = 'zestcapital.com.pe';
      $mail->SMTPAuth   = true;
      $mail->SMTPDebug  = 1;
      $mail->Username   = 'noreply@zestcapital.com.pe';
      $mail->Password   = 'Cambiar01#';
      $mail->SMTPSecure = 'tls';
      $mail->Port       = 587;

      $mail->setFrom('noreply@zestcapital.com.pe', 'ZEST Capital');
      $mail->addAddress($email);

      $mail->isHTML(true);
      $mail->CharSet = 'UTF-8';
      $mail->Subject = 'Confirmación: Taller de Inversiones Zest - IBM, Sala Cuzco';
      $mail->Body    = '
      <html lang="es">
      <head>
        <title></title>
        <style>*{padding:0;margin:0;}</style>
      </head>
      <body>hola</body></html>';
*/
      //$mail->Send();

      if ($mail->Send()) { 
        http_response_code(201);
        echo json_encode(array("message" => "! Se envio su consulta! "));
      }else {
        http_response_code(400);
        echo json_encode(array("message" => "Error al enviar el mensaje"));
      }

      //echo json_encode(array("message" => "! Se envio su consulta2! "));
    }catch (Exception $e)
    {
      http_response_code(400);
       //echo $e->errorMessage();
       echo json_encode(array("message" => "Error : ". $e->errorMessage() ));
    }
    catch (\Exception $e)
    {
      http_response_code(400);
       //echo $e->getMessage();
       echo json_encode(array("message" => "Error : ". $e->getMessage() ));
    }
      

  }

}
/*
else{

  http_response_code(405);
  echo json_encode(array("message" => "Method not allowed"));

}
*/
?>